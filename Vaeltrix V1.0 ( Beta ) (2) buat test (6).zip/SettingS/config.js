module.exports = {
  tokenBot: "TOKEN_BOT",
  ownerID: "OWNER_ID",
};
